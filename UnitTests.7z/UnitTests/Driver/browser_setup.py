browser_setup = {
    "browser" : "Firefox",
    "url" : "http://localhost:3183/home/events?page=1"
}

#Chrome