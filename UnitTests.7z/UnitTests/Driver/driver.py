import os

path = os.path.abspath(os.path.dirname(__file__) + '\\geckodriver')